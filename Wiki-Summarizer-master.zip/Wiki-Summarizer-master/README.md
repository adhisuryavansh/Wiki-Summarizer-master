# Wiki-Summarizer
This is a simple Python program which summarizes and save wiki search in a text file.

You can search anything in the Search Box as shown below:

<img src="/searchbox.png" alt="My cool logo"/>

And the result is:

<img src="/searchresult.png" alt="My cool logo"/>
